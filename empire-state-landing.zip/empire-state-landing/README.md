# EMPIRE STATE

A GTA-style open-world crime game set in New York.

5 boroughs. 3 criminals + 1 honest cop. One hard drive that can bring down the mayor.

## Landing page

Next.js 14 App Router + React + TypeScript strict + Tailwind + Framer Motion.

- Interactive NYC map (SVG, < 200KB)
- Character switcher: Dario / Maya / Frankie / Marcus
- Story timeline: Act I / II / III
- Ending simulator: king | burn | ghost | arrest

## Data

- `boroughs.json` — 5 boroughs, missions, factions
- `characters.json` — 4 protagonists, skills
- `endings.json` — 4 endings

## Plan

- Day 1: scaffold
- Day 2: map + Hero
- Day 3: character switcher + timeline
- Day 4: ending simulator
- Day 5: Playwright E2E + Lighthouse 90+

## Architecture

See `empire-state-architecture.png`.
